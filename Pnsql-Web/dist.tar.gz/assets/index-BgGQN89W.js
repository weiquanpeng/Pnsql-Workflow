import{g as e}from"./index-CgngWMcA.js";const n={};function r(c,t){return null}const o=e(n,[["render",r]]);export{o as default};
