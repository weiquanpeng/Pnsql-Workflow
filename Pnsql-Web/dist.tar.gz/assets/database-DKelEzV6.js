import{g as e}from"./index-CgngWMcA.js";const r={};function t(c,n){return null}const s=e(r,[["render",t]]);export{s as default};
